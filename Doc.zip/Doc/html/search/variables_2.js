var searchData=
[
  ['cha_0',['cha',['../class_player.html#adbd725dd40d6d707d500dbd9dea0d6b1',1,'Player']]],
  ['coins_1',['Coins',['../class_player.html#a2b9534c34e432a9e2e8c63f6364e19e9',1,'Player']]],
  ['crit_5fmult_2',['crit_mult',['../class_player.html#aa067b8a2d3263da3ae92ad611e6c624d',1,'Player']]],
  ['currentarmor_3',['CurrentArmor',['../class_player.html#a54fefd45964cad5e0a9248379acce36f',1,'Player']]],
  ['currentlvl_4',['CurrentLvl',['../class_level_sys.html#a75a9c823937cae636188aa5b8ddb2b40',1,'LevelSys']]],
  ['currentweapon_5',['CurrentWeapon',['../class_player.html#a6ff82541d2239ec3734d9c747b3597b2',1,'Player']]],
  ['currentxp_6',['CurrentXp',['../class_level_sys.html#aa93c4d21980cd2a8b6f66c69ec19a047',1,'LevelSys']]]
];
