var indexSectionsWithContent =
{
  0: "abcdefghilnopstvwx",
  1: "acfgloptw",
  2: "f",
  3: "acdfghilpstx",
  4: "abcdeghilnpstvx",
  5: "ls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends"
};

