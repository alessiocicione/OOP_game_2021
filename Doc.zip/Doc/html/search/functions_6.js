var searchData=
[
  ['isalive_0',['IsAlive',['../class_player.html#a1e37ef4863425e6b8cf74752c3673628',1,'Player']]],
  ['isbot_1',['IsBot',['../class_player.html#a2844c17bcdabd13b393cd548db7c5d95',1,'Player']]]
];
