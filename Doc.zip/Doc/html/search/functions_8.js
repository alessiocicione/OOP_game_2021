var searchData=
[
  ['player_0',['Player',['../class_player.html#a5b6e5be3ee1d9fc7db7e6ffbb9c0cafd',1,'Player']]]
];
