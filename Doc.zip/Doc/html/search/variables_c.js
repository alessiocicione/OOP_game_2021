var searchData=
[
  ['turncount_0',['TurnCount',['../class_floor.html#a55d4f2f2349bc4f23425d28cf2b69217',1,'Floor']]]
];
