var searchData=
[
  ['agi_0',['agi',['../class_player.html#a9a45b1b5a6198bcb09b5f184111cb3b8',1,'Player']]],
  ['alive_1',['Alive',['../class_player.html#a3f8a961fe362a10aeba975e2609cb08c',1,'Player']]],
  ['atk_2',['atk',['../class_player.html#a05c91bea7717cff003ff4ef262cbf2e3',1,'Player']]]
];
