var searchData=
[
  ['turn_0',['Turn',['../class_turn.html',1,'Turn'],['../class_turn.html#ac6cad94a14d51967212f6fcd8e0938f4',1,'Turn::Turn()']]],
  ['turncount_1',['TurnCount',['../class_floor.html#a55d4f2f2349bc4f23425d28cf2b69217',1,'Floor']]]
];
