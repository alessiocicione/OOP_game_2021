var searchData=
[
  ['bot_0',['BOT',['../class_player.html#a61e9ee2a40f6ec0b48203d464982b1e2',1,'Player']]]
];
