var searchData=
[
  ['def_0',['def',['../class_player.html#af93595b7910c3ced000fa5962b1900aa',1,'Player']]]
];
