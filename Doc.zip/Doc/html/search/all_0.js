var searchData=
[
  ['addcoins_0',['AddCoins',['../class_player.html#a33cb186a4290114f0744b7a4fc017be9',1,'Player']]],
  ['advlvl_1',['AdvLvl',['../class_level_sys.html#a32b55cd8165f1e15b69588a595fbb4bf',1,'LevelSys']]],
  ['agi_2',['agi',['../class_player.html#a9a45b1b5a6198bcb09b5f184111cb3b8',1,'Player']]],
  ['alive_3',['Alive',['../class_player.html#a3f8a961fe362a10aeba975e2609cb08c',1,'Player']]],
  ['applyeffect_4',['ApplyEffect',['../class_weapon.html#a8e5026955d68b2d0c71b4a9aafec15a7',1,'Weapon::ApplyEffect()'],['../class_armor.html#a9d2ee17f3927fe3ed5601a713eb9c29d',1,'Armor::ApplyEffect()']]],
  ['armor_5',['Armor',['../class_armor.html',1,'']]],
  ['atk_6',['atk',['../class_player.html#a05c91bea7717cff003ff4ef262cbf2e3',1,'Player']]],
  ['attack_7',['Attack',['../class_player.html#ad372b924a5a63e53854d1350512972d9',1,'Player']]],
  ['autochoice_8',['AutoChoice',['../class_player.html#a197e2a85525a51aa694f1802dc324288',1,'Player']]]
];
