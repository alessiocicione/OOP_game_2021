var searchData=
[
  ['name_0',['name',['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['namecolor_1',['NameColor',['../class_weapon.html#a0b27a9f567d6cb8e1015a8fac981b41c',1,'Weapon::NameColor()'],['../class_armor.html#a54788937ee2e7813734d51594f87890a',1,'Armor::NameColor()']]]
];
