var searchData=
[
  ['turn_0',['Turn',['../class_turn.html#ac6cad94a14d51967212f6fcd8e0938f4',1,'Turn']]]
];
