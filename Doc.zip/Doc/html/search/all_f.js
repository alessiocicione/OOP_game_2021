var searchData=
[
  ['varamount_0',['VarAmount',['../class_object.html#a70a555f628f893fab9d06d1e9d2868b9',1,'Object']]],
  ['varatk_1',['VarAtk',['../class_weapon.html#a69f1b72978616ba4472e2b35e15205d8',1,'Weapon']]],
  ['vardef_2',['VarDef',['../class_armor.html#aea99ab491cad086abf365fd010cc9c2d',1,'Armor']]],
  ['vartype_3',['VarType',['../class_object.html#a09cd23da8236aba6b7322c73f9852a42',1,'Object']]]
];
