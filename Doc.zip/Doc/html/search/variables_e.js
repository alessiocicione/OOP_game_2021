var searchData=
[
  ['xptonext_0',['XpToNext',['../class_level_sys.html#a654515532f57f8e005c003d99f395402',1,'LevelSys']]]
];
