var searchData=
[
  ['per_0',['per',['../class_player.html#a5323c6338e163e2e34b4766c4f7523a5',1,'Player']]],
  ['player_1',['Player',['../class_player.html',1,'Player'],['../class_player.html#a5b6e5be3ee1d9fc7db7e6ffbb9c0cafd',1,'Player::Player(int Vdef, int Vatk, string Vname, bool Auto=false, int Vstr=1, int Vper=1, int Vend=1, int Vcha=1, int Vin=1, int Vagi=1, int Vlck=1)']]],
  ['playerlevel_2',['PlayerLevel',['../class_player.html#ab20778cdc228f74be2f45f4ae32dc065',1,'Player']]]
];
